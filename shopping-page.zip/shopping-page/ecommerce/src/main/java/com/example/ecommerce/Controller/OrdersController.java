package com.example.ecommerce.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ecommerce.Entity.Orders;
import com.example.ecommerce.Entity.Product;
import com.example.ecommerce.Entity.User;
import com.example.ecommerce.Repository.OrdersRepository;
import com.example.ecommerce.Repository.UserRepository;

@CrossOrigin
@RestController
@RequestMapping("api/orders")
public class OrdersController {

	@Autowired
	OrdersRepository orderRepository;
	
	@Autowired
	UserRepository userRepo;
	
	@GetMapping("getByUserId/{user_id}")
	public List<Orders> getByUserId(@PathVariable Long user_id)
	{
		return orderRepository.findByUserId(user_id);
	}
	
	@GetMapping("create/{user_id}/{productName}")
    public String createOrder(@PathVariable Long user_id, @PathVariable String productName) {

        Orders order = new Orders();
        order.setName(productName);
        order.setUser_id(user_id);
        
        orderRepository.save(order);
        return "Order created succesfully"; 
	}
	
	@GetMapping("cancel/{orderId}")
	public String cancel(@PathVariable Long orderId)
	{
		Optional<Orders> orders = orderRepository.findById(orderId);
		
		if(orders != null)
		{
			orderRepository.delete(orders.get());
			return "The order canceled!";
		}
		return "There is no order";
	}
}
