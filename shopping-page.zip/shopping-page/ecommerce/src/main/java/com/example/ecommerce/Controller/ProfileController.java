package com.example.ecommerce.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ecommerce.Entity.Profile;
import com.example.ecommerce.Entity.User;
import com.example.ecommerce.Repository.ProfileRepository;
import com.example.ecommerce.Repository.UserRepository;

@CrossOrigin
@RestController
@RequestMapping("api/profile")
public class ProfileController {

	@Autowired
	ProfileRepository profileRepo;
	
	@Autowired
	UserRepository userRepo;
	
	@GetMapping("getAll")
	public List<Profile> getAll()
	{
		return profileRepo.findAll();
	}
	
	@GetMapping("getByuser_id/{user_id}")
	public Profile  getByuser_id(@PathVariable Long user_id)
	{
		Profile profile = profileRepo.findByUser_id(user_id).get();
		if(profile != null)
			return profile;
		
		profile = new Profile();
		return null;
	}
	
	@GetMapping("getUser/{user_id}")
	public User getUser(@PathVariable Long user_id)
	{
		Optional<User> optionalUser = userRepo.findById(user_id);
		
		if(optionalUser.isEmpty())
			return null;
		return optionalUser.get();
	}
}
