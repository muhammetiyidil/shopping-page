package com.example.ecommerce.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ecommerce.Entity.User;
import com.example.ecommerce.Repository.UserRepository;

@CrossOrigin
@RestController
@RequestMapping("api/user")
public class UserController {
	
    @Autowired
    private UserRepository userRepository;
    
    Long userId;

    @GetMapping("login/{email}/{password}")
    public Long Login(@PathVariable String email, @PathVariable String password)
    {
    	userId = 0L;
    	Optional<User> user = userRepository.findAll().stream()
    	.filter(u -> u.getEmail().equals(email)&& u.getPassword().equals(password))
    	.findFirst();
    	
    	if(user.isEmpty())
    		return -1L;
    	
    	return user.get().getId();
    }
}