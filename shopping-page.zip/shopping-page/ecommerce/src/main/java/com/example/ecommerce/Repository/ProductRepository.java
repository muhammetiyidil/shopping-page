package com.example.ecommerce.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ecommerce.Entity.Product;
import com.example.ecommerce.Entity.Profile;

public interface ProductRepository extends JpaRepository<Product, Long> {}
