	package com.example.ecommerce.Controller;
	
	import java.util.List;
	import java.util.Optional;
	
	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;
	
	import com.example.ecommerce.Entity.Product;
	import com.example.ecommerce.Repository.ProductRepository;
	
	@CrossOrigin
	@RestController
	@RequestMapping("api/product")
	public class ProductController {
		
		@Autowired
		private ProductRepository productRepo;
		
		String output;
		
		@GetMapping("getAll")
		public String getAll(){
			 output =  "";
			 productRepo.findAll().forEach(p -> {
				output += p.getName()+"<br>";
				output += p.getPrice()+"<br>";
				output += p.getStock()+"<br>";
				output += p.getCategory().getName()+"<br><br>";
			});
			 return output;
		}
		
		@GetMapping("{id}")
		public Optional<Product> getProduct(Long id){
			return productRepo.findById(id);
		}
	}
